package controller;

import model.Avaliacao;
import model.Categoria;
import service.AvaliacaoService;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class AvaliacaoController extends HttpServlet {

    private final AvaliacaoService service = new AvaliacaoService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        try {
            Avaliacao a = new Avaliacao();
            a.setFilmeId(Integer.parseInt(req.getParameter("filme")));
            a.setCategoriaId(Integer.parseInt(req.getParameter("categoria")));
            a.setNota(Integer.parseInt(req.getParameter("nota")));
            a.setComentario(req.getParameter("comentario"));

            service.avaliar(a);

            if (querJson(req)) {
                escreverJson(resp, "{\"mensagem\":\"Avaliacao registrada com sucesso.\"}");
            } else {
                resp.sendRedirect(req.getContextPath() + "/avaliacoes?action=ranking&categoriaId=" + a.getCategoriaId());
            }
        } catch (RuntimeException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            escreverJson(resp, "{\"erro\":\"" + escaparJson(e.getMessage()) + "\"}");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) action = "ranking";

        try {
            switch (action) {
                case "form":
                    req.setAttribute("filmeId", req.getParameter("filmeId"));
                    req.setAttribute("categorias", service.listarCategorias());
                    req.getRequestDispatcher("/view/avaliar.jsp").forward(req, resp);
                    break;

                case "categorias":
                    escreverJson(resp, categoriasParaJson());
                    break;

                case "ranking":
                default:
                    int categoriaId = lerCategoria(req);
                    List<String> ranking = service.ranking(categoriaId);

                    if (querJson(req)) {
                        escreverJson(resp, rankingParaJson(ranking));
                    } else {
                        req.setAttribute("ranking", ranking);
                        req.setAttribute("categorias", service.listarCategorias());
                        req.setAttribute("categoriaSelecionada", categoriaId);
                        req.getRequestDispatcher("/view/ranking.jsp").forward(req, resp);
                    }
                    break;
            }
        } catch (RuntimeException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            escreverJson(resp, "{\"erro\":\"" + escaparJson(e.getMessage()) + "\"}");
        }
    }

    private int lerCategoria(HttpServletRequest req) {
        String categoria = req.getParameter("categoria");
        if (categoria == null || categoria.trim().isEmpty()) {
            categoria = req.getParameter("categoriaId");
        }
        if (categoria == null || categoria.trim().isEmpty()) return 1;
        return Integer.parseInt(categoria);
    }

    private String categoriasParaJson() {
        StringBuilder sb = new StringBuilder("[");
        List<Categoria> categorias = service.listarCategorias();
        for (int i = 0; i < categorias.size(); i++) {
            Categoria c = categorias.get(i);
            sb.append("{\"id\":").append(c.getId())
                    .append(",\"nome\":\"").append(escaparJson(c.getNome())).append("\"}");
            if (i < categorias.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    private String rankingParaJson(List<String> ranking) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < ranking.size(); i++) {
            sb.append("\"").append(escaparJson(ranking.get(i))).append("\"");
            if (i < ranking.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    private boolean querJson(HttpServletRequest req) {
        String accept = req.getHeader("Accept");
        return accept != null && accept.contains("application/json");
    }

    private void escreverJson(HttpServletResponse resp, String json) throws IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        out.print(json);
        out.flush();
    }

    private String escaparJson(String valor) {
        if (valor == null) return "";
        return valor.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }
}
