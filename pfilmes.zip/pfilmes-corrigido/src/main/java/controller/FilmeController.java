package controller;

import model.Filme;
import service.FilmeService;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class FilmeController extends HttpServlet {

    private final FilmeService service = new FilmeService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) action = "listar";

        try {
            switch (action) {
                case "novo":
                    req.getRequestDispatcher("/view/formFilme.jsp").forward(req, resp);
                    break;

                case "editar": {
                    int id = Integer.parseInt(req.getParameter("id"));
                    req.setAttribute("filme", service.buscarPorId(id));
                    req.getRequestDispatcher("/view/editarFilme.jsp").forward(req, resp);
                    break;
                }

                case "deletar": {
                    int id = Integer.parseInt(req.getParameter("id"));
                    service.deletar(id);
                    resp.sendRedirect(req.getContextPath() + "/filmes");
                    break;
                }

                case "buscar": {
                    int id = Integer.parseInt(req.getParameter("id"));
                    Filme f = service.buscarPorId(id);
                    if (f == null) {
                        resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                        escreverJson(resp, "{\"erro\":\"Filme nao encontrado.\"}");
                    } else {
                        escreverJson(resp, filmeParaJson(f));
                    }
                    break;
                }

                case "listar":
                    List<Filme> filmes = service.listar();
                    if (querJson(req)) {
                        escreverJson(resp, filmesParaJson(filmes));
                    } else {
                        req.setAttribute("filmes", filmes);
                        req.getRequestDispatcher("/view/filmes.jsp").forward(req, resp);
                    }
                    break;

                default:
                    resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    escreverJson(resp, "{\"erro\":\"Acao desconhecida.\"}");
            }
        } catch (RuntimeException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            escreverJson(resp, "{\"erro\":\"" + escaparJson(e.getMessage()) + "\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");
        if (action == null) action = "salvar";

        try {
            switch (action) {
                case "salvar": {
                    Filme f = montarFilme(req);
                    service.salvar(f);
                    responderSucesso(req, resp, HttpServletResponse.SC_CREATED, "Filme cadastrado com sucesso.");
                    break;
                }

                case "atualizar": {
                    Filme f = montarFilme(req);
                    f.setId(Integer.parseInt(req.getParameter("id")));
                    service.atualizar(f);
                    responderSucesso(req, resp, HttpServletResponse.SC_OK, "Filme atualizado com sucesso.");
                    break;
                }

                default:
                    resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    escreverJson(resp, "{\"erro\":\"Acao desconhecida.\"}");
            }
        } catch (RuntimeException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            if (querJson(req)) {
                escreverJson(resp, "{\"erro\":\"" + escaparJson(e.getMessage()) + "\"}");
            } else {
                resp.sendRedirect(req.getContextPath() + "/filmes");
            }
        }
    }

    private Filme montarFilme(HttpServletRequest req) {
        Filme f = new Filme();
        f.setTitulo(req.getParameter("titulo"));
        f.setAnoLancamento(Integer.parseInt(req.getParameter("ano")));
        f.setDiretor(req.getParameter("diretor"));
        f.setGenero(req.getParameter("genero"));
        f.setSinopse(req.getParameter("sinopse"));
        return f;
    }

    private void responderSucesso(HttpServletRequest req, HttpServletResponse resp, int status, String mensagem)
            throws IOException {
        if (querJson(req)) {
            resp.setStatus(status);
            escreverJson(resp, "{\"mensagem\":\"" + escaparJson(mensagem) + "\"}");
        } else {
            resp.sendRedirect(req.getContextPath() + "/filmes");
        }
    }

    private boolean querJson(HttpServletRequest req) {
        String accept = req.getHeader("Accept");
        return accept != null && accept.contains("application/json");
    }

    private void escreverJson(HttpServletResponse resp, String json) throws IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        out.print(json);
        out.flush();
    }

    private String filmeParaJson(Filme f) {
        return "{\"id\":" + f.getId()
                + ",\"titulo\":\"" + escaparJson(f.getTitulo()) + "\""
                + ",\"anoLancamento\":" + f.getAnoLancamento()
                + ",\"diretor\":\"" + escaparJson(f.getDiretor()) + "\""
                + ",\"genero\":\"" + escaparJson(f.getGenero()) + "\""
                + ",\"sinopse\":\"" + escaparJson(f.getSinopse()) + "\"}";
    }

    private String filmesParaJson(List<Filme> filmes) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < filmes.size(); i++) {
            sb.append(filmeParaJson(filmes.get(i)));
            if (i < filmes.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    private String escaparJson(String valor) {
        if (valor == null) return "";
        return valor.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }
}
