package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import model.Avaliacao;
import util.ConnectionFactory;

public class AvaliacaoDAO {

    private final ConnectionFactory cf = ConnectionFactory.getInstance();

    public void avaliar(Avaliacao a) {
        String sql = "INSERT INTO avaliacoes (filme_id, categoria_id, nota, comentario) VALUES (?, ?, ?, ?)";

        try (Connection conn = cf.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, a.getFilmeId());
            stmt.setInt(2, a.getCategoriaId());
            stmt.setInt(3, a.getNota());
            stmt.setString(4, a.getComentario());
            stmt.execute();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao registrar avaliacao.", e);
        }
    }

    public List<String> ranking(int categoriaId) {
        List<String> lista = new ArrayList<>();

        String sql = "SELECT f.titulo, AVG(a.nota) AS media, COUNT(*) AS total "
                + "FROM avaliacoes a "
                + "JOIN filmes f ON f.id = a.filme_id "
                + "WHERE a.categoria_id = ? "
                + "GROUP BY f.id, f.titulo "
                + "ORDER BY media DESC";

        try (Connection conn = cf.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, categoriaId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                lista.add(rs.getString("titulo")
                        + " | Media: " + String.format(Locale.US, "%.1f", rs.getDouble("media"))
                        + " | Avaliacoes: " + rs.getInt("total"));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao gerar ranking.", e);
        }

        return lista;
    }
}
