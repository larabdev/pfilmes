# CineList / pFilmes

Site MVC em Java para sugestoes e avaliacoes de filmes, com telas JSP, banco MySQL, autenticacao JWT e API RESTful em JSON.

## Como rodar no VS Code com Tomcat

1. Execute o script `banco.sql` no MySQL.
2. Confira a conexao em `src/main/java/util/ConnectionFactory.java`.
3. Compile o projeto e gere o WAR.
4. Publique o arquivo `pfilmes.war` na pasta `webapps` do Tomcat.
5. Acesse:

```text
http://localhost:8080/pfilmes
```

Usuario padrao:

- E-mail: `admin@filmes.com`
- Senha: `123456`

## O que foi implementado

As rotas REST foram implementadas nos controllers existentes, sem criar controller separado:

- `FilmeController` atende as telas JSP em `/filmes` e a API em `/api/filmes`.
- `AvaliacaoController` atende as telas JSP em `/avaliacoes` e a API em `/api/avaliacoes`.

A API usa:

- JSON no corpo da requisicao.
- Verbos HTTP RESTful: `GET`, `POST`, `PUT` e `DELETE`.
- CRUD completo para filmes.
- CRUD completo para avaliacoes.
- JWT no header `Authorization`.

## Login

`POST /login`

```bash
curl -X POST http://localhost:8080/pfilmes/login ^
  -H "Accept: application/json" ^
  -d "email=admin@filmes.com" ^
  -d "senha=123456"
```

Resposta:

```json
{"token":"SEU_TOKEN_JWT"}
```

Use o token assim:

```text
Authorization: Bearer SEU_TOKEN_JWT
```

## API RESTful de filmes

### Criar filme

`POST /api/filmes`

```json
{
  "titulo": "Interestelar",
  "anoLancamento": 2014,
  "diretor": "Christopher Nolan",
  "genero": "Ficcao Cientifica",
  "sinopse": "Viagem espacial."
}
```

### Listar filmes

`GET /api/filmes`

### Buscar filme por id

`GET /api/filmes/1`

### Atualizar filme

`PUT /api/filmes/1`

```json
{
  "titulo": "Interestelar",
  "anoLancamento": 2014,
  "diretor": "Christopher Nolan",
  "genero": "Sci-Fi",
  "sinopse": "Filme atualizado."
}
```

### Excluir filme

`DELETE /api/filmes/1`

## API RESTful de avaliacoes

### Criar avaliacao

`POST /api/avaliacoes`

```json
{
  "filmeId": 1,
  "categoriaId": 1,
  "nota": 5,
  "comentario": "Excelente."
}
```

### Listar avaliacoes

`GET /api/avaliacoes`

### Buscar avaliacao por id

`GET /api/avaliacoes/1`

### Atualizar avaliacao

`PUT /api/avaliacoes/1`

```json
{
  "filmeId": 1,
  "categoriaId": 1,
  "nota": 4,
  "comentario": "Comentario atualizado."
}
```

### Excluir avaliacao

`DELETE /api/avaliacoes/1`

## Categorias e ranking

Listar categorias:

`GET /api/categorias`

Ranking por categoria:

`GET /api/avaliacoes/ranking?categoriaId=1`

## Telas JSP

- `/login.jsp`: login.
- `/filmes`: lista de filmes.
- `/filmes?action=novo`: cadastro.
- `/filmes?action=editar&id=1`: edicao.
- `/avaliacoes?action=form&filmeId=1`: avaliar filme.
- `/avaliacoes?action=ranking&categoriaId=1`: ranking.
